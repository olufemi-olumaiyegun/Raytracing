from functions import color,vector,image,sphere,point,ray,scene,Engine_Render,material,light
import math,random
def main():

    print("Copyright: Olufemi Olumaiyegun")
    print("?|?|?|?|||||||??|?|||?|??||?|||?|||||||????|?|?||?|?|?|?|?|?|?|?|?|?|?")
    print("Hey! Welcome to my ray tracer")

    WIDTH = 2160
    HEIGHT = 1560
    spikes = 40
    radius = 0.2
    stem_length = 3
    stem_radius = 0.008
    blob_radius = 0.01
    camera = vector(0,0,-1)
    objects = [sphere(point(0,0,0),radius, material(color.from_hex("#800080")))]
    lights = [light(point(14.5,-4.5,-10.0),color.from_hex("#FFFFFF"))]
    for i in range(spikes):
        angle = math.radians(360/spikes*i+random.randint(-2,2))
        for j in range(stem_length):
            #polar coordinatte conversion
            x  = (radius + stem_radius * j) * math.sin(angle)
            y = (radius + stem_radius * j) * math.cos(angle)
            objects.append(sphere(point(x,y,0), stem_radius, material(color.from_hex("#d47721"))))
    #end blob
    x = (radius + stem_radius * j + blob_radius) * math.sin(angle)
    y = (radius + stem_radius * j + blob_radius) * math.cos(angle)
    objects.append(sphere(point(x,y,0), blob_radius, material(color.from_hex("#febd141"))))

    the_scene = scene(camera, objects,lights, WIDTH, HEIGHT)
    rendering_engine= Engine_Render()
    Image = rendering_engine.renderNow(the_scene)

    with open("image.ppm","w") as myfile:
        Image.create_file_ppm(myfile)
    myfile.close()



if __name__ == "__main__":
    main()